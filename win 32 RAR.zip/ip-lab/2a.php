<html>
  <body>
        <h1>Enter your name:</h1>
         <form action="/ip-lab/2a-greet.php" method="post"> 
            <input type="text" name="username">
            <button type="submit">Submit</button>
        </form>
  </body>
</html>