<?php
	
	function getConnection()
    {
        $con = new mysqli("localhost", "root", "root", "ip_lab");
        
        if($con->connect_error) die("Connection failed: " . $con->connect_error);
		
		return $con;
    }

    function showColumns($query)
    {
        $con = getConnection();
        $result = $con->query($query)->fetch_all();
        echo "<tr>";
		foreach($result as $r)
            echo "<th>$r[0]</th>";
		echo "</tr>";
        $con->close();
    }
    
	function showDetails($query, $cardinals)
    {
        $con = getConnection();
        $result = $con->query($query)->fetch_all();
        if(count($result) != 0)
        {
            foreach($result as $r)
            {
                echo "<tr>";
                for($i = 0; $i < $cardinals; $i++)
                    echo "<td>$r[$i]</td>";
                echo "</tr>";
            }
        }
        $con->close();
    }
	
?>

<html>
<body>
    <h1>Query the database</h1>

    <h2>Your databases</h2>
    <code><table border=1><?php showDetails("SHOW DATABASES", 1); ?></table></code>

    <h2>User database</h2>
    <table border=1>
        <?php showColumns("SHOW COLUMNS FROM `users`;", 1); ?>
        <?php showDetails("SELECT * FROM `users`;", 3);?>
    </table>

    <h2>Book database</h2>
    <table border=1>
        <?php showColumns("SHOW COLUMNS FROM `books`;", 1); ?>
        <?php showDetails("SELECT * FROM `books`;", 5); ?>
    </table>
</body>
</html>