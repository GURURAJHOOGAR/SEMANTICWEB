<html>
<body>
    <h1>Add Book</h1>
    <form action='' method='post'>
        <hr> 
        <label>ISBN: <input name='isbn' type='text' required></label>
        <br><br>
        <label>Title: <input name='title' type='text' required></label>
        <br><br>
        <label>Author: <input name='auth' type='text' required></label>
        <br><br>
        <label>Edition: <input name='ed' type='number' required></label>
        <br><br>
        <label>Publication: <input name='pub' type='text' required></label>
        <br><br>         
        <button type='submit'>Submit</button>
        <hr> 
    </form>
</body>
</html>

<?php

	if($_SERVER['REQUEST_METHOD'] == 'POST') 
	{	
		$con = new mysqli("localhost", "root", "root", "ip_lab");

		if($con->connect_error) die("Connection failed: " . $con->connect_error);
		
		$isbn = $_POST['isbn'];
		$title = $_POST['title'];
		$author = $_POST['auth'];
		$edition = $_POST['ed'];
		$pub = $_POST['pub'];
		
		$query = $con->prepare("INSERT INTO `books` VALUES (?, ?, ?, ?, ?)");
		$query->bind_param("sssis", $isbn, $title, $author, $edition, $pub);
        $result = $query->execute();
		
		echo "<h3>Successfully Added!!! <a href='/ip-lab/7.php'>Click Here</a> to View</h3>";

		$con->close();

	}

?>