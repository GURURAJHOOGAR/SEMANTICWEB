-- Create Database
drop database if exists ip_lab;
create database ip_lab;
use ip_lab;

-- Definition of table `users`
create table `users` (
    `id` int not null auto_increment,
    `username` varchar(45) not null,
	`age` int not null,
    primary key(`id`)
);

-- Definition of table `books`
create table `books` (
    `isbn` varchar(13) not null,
    `title` varchar(45) not null,
    `author` varchar(45) not null,
    `edition` int not null,
    `publication` varchar(45) not null,
    primary key(`isbn`)
	);

-- Data for table `users`
insert into `users`(username, age) VALUES
("Steve", 23),
("Jason", 28),
("James", 24),
("Smith", 32),
("David", 23),
("Peter", 39);

-- Data for table `books`
insert into `books` (`isbn`,`title`,`author`,`edition`,`publication`) VALUES 
('10001', 'C Programming', 'D Ritchie', 2, 'MH Publications'),
('10002', 'Java For Beginners', 'HB Swamy', 3, 'Sapna Publications'),
('10003', 'PHP for Beginners', 'A Rasmus', 1, 'EBP Publications'),
('10004', 'XML for Dummies', 'A Morgan', 2, 'Sapna Publications'),
('10005', 'Java Complete Reference', 'H Schildt', 4, 'MH Publications'),
('10006', 'SQL Complete Reference', 'S Smith', 5, 'EBP Publications');


