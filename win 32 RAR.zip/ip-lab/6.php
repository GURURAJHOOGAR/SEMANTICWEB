<html>
<body>
    <form action='' method='post'>
        <h1>Add</h1>
		<hr> 
        <label>User Name: <input name='username' type='text' required></label>
        <br><br>
        <label>Age: <input name='age' type='number' max='99' required></label>
        <br><br>         
        <button type='submit'>Submit</button>
        <hr> 
    </form>
</body>
</html>

<?php

	if($_SERVER['REQUEST_METHOD'] == 'POST') 
	{	
		$con = new mysqli("localhost", "root", "root", "ip_lab");

		if($con->connect_error) die("Connection failed: " . $con->connect_error);
		
		$name = $_POST['username'];
		$age = $_POST['age'];
		
		$query = $con->prepare("INSERT INTO `users`(username, age) VALUES (?, ?)");
		$query->bind_param("si", $name, $age);
		$result = $query->execute();
		
		echo "<h3>Successfully Added!!! <a href='/ip-lab/5.php'>Click Here</a> to View</h3>";

		$con->close();

	}

?>