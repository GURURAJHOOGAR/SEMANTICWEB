<?php
	
	session_start();
	
    if(!isset($_SESSION['hits']))
	{
		$_SESSION['hits'] = 1;
		echo "<h2>You are the first visitor.</h2>";
	}
	else
	{
		$_SESSION['hits'] = $_SESSION['hits'] + 1;
		echo "<h2>You are visitor number ". $_SESSION['hits'] ."</h2>";
	}

?>
