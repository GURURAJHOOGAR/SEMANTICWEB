<?php
    $name = $_POST["username"];

	if(trim($name) == "")
		echo "<h1>Who are you?</h1>";
	else
		echo "<h1>Welcome, $name</h1>";
?>