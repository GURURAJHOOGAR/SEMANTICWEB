<html>
<head>
<script>
function printTime() {
    document.getElementById('time').innerHTML = (new Date).toLocaleTimeString();
    setTimeout(printTime, 500);
}
</script>
</head>
<body onload="printTime()">
<center>
<h1>Dynamic Time using Javascript</h1>
<h2><div id="time"></div></h2>

<?php
	date_default_timezone_set("Asia/Kolkata");
	$time = date("g:i:s A");	//1:11:47 AM
	$date = date("l, d F, Y");	//Saturday, 04 November, 2017
	echo "<h3>$date<h3>";
?>
</center>
</body>
</html>