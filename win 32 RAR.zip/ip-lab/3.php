<?php

    function greet()
    {
		date_default_timezone_set("Asia/Kolkata");
		
		$hour = intval(date('H'));
        
		if ($hour >= 6 && $hour < 12)
            return "Good morning!";
        else if ($hour < 16)
            return "Good afternoon!";
        else if ($hour < 21)
            return "Good evening!";
        return "Good night!";
    }
	
?>

<html>
<body>
    <h1><?php echo greet(); ?></h1>
    <form action='/ip-lab/3-checkLogin.php' method='post'>
        Enter user name to check login status: <input type='text' name='user' required>
        <button type='submit'>Check</button>
    </form>
</body>
</html>