<?php

    $con = new mysqli("localhost", "root", "root", "ip_lab");

    if($con->connect_error) die("Connection failed: " . $con->connect_error);
	
	$sql = 'SELECT * FROM users';
	$result = $con->query($sql);
	
	if($result->num_rows > 0)
	{
		echo "<h1>Data in 'users' table</h1>";
		echo "<table border='1'>";
		echo "<tr><th>ID</th><th>Name</th><th>Age</th></tr>";
		
		while($row = $result->fetch_assoc())
		{
			echo "<tr>";
			echo "<td>" . $row['id']		. "</td>";
			echo "<td>" . $row['username']	. "</td>";
			echo "<td>" . $row['age']		. "</td>";
			echo "</tr>";
		}
		
		echo "</table>";
	}
	else
	{
		echo "</h2>The Table is Empty</h2>";
	}
		
	$result->free();
	$con->close();
	
?>