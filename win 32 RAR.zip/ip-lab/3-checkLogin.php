<?php

	$username = $_REQUEST['user'];
	
	// TODO: Write function to get array of logged in users
	
	$loggedInUsers = array('uvce', 'admin', 'root', 'webmaster');
	
	if(in_array($username, $loggedInUsers))
		echo "<h2>'$username' is Logged in.</h2>";
	else
		echo "<h2>'$username' is Not Logged in.</h2>";
		
?>