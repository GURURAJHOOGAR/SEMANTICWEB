<?php
echo "
		<h1>Server Info</h1>
		
		Server Name:	   $_SERVER[SERVER_NAME]        <br>
		Server Port:	   $_SERVER[SERVER_PORT]        <br>
		Server Software:   $_SERVER[SERVER_SOFTWARE]    <br>
		Server Protocol:   $_SERVER[SERVER_PROTOCOL]    <br>
		CGI Version:	   $_SERVER[GATEWAY_INTERFACE]  <br>
		Root Document:	   $_SERVER[DOCUMENT_ROOT]      <br>
	  
	  ";
?>