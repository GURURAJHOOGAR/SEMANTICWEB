<html>
<body>
    <h1>Search The Database</h1>
    <form method='post' action=''>
		<select name='col'>
		<option value='isbn'>ISBN</option>
		<option value='title' selected>Title</option>
		<option value='author'>Author</option>
		<option value='publication'>Publication</option>
		</select>
		<label><input type='text' placeholder='java' name='query'></label>
        <button type='submit'>Search</button>
		<br><br><hr>
    </form>
</body>
</html>

<?php
	
	if($_SERVER['REQUEST_METHOD'] == 'POST') 
	{
		$con = new mysqli("localhost", "root", "root", "ip_lab");

		if($con->connect_error) die("Connection failed: " . $con->connect_error);
		
		$col = $_POST['col'];
		$q= $_POST['query'];
		
		$sql = "SELECT * FROM `books` WHERE LOWER($col) LIKE '%$q%'";
		$result = $con->query($sql);
		
		if($result->num_rows > 0)
		{
			echo "<h2>Search Results for '$q'</h2>";
			
			echo "<table border='1'>";
			echo "<tr><th>ISBN</th><th>Title</th><th>Author</th><th>Edition</th><th>Publication</th></tr>";
			
			while($row = $result->fetch_assoc())
			{
				echo "<tr>";
				echo "<td>" . $row['isbn'] 			. "</td>";
				echo "<td>" . $row['title'] 		. "</td>";
				echo "<td>" . $row['author'] 		. "</td>";
				echo "<td>" . $row['edition'] 		. "</td>";
				echo "<td>" . $row['publication']	. "</td>";
				echo "</tr>";
			}
			
			echo "</table>";
		}
		else
		{
			echo "<h2>No matching rows.</h2>";
		}
			
		$result->free();
		$con->close();
	}
	
?>