import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class CreateCookies extends HttpServlet
{
	public void doPost (HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{		
		String username = req.getParameter("username");
		String city =  req.getParameter("city");
		
		Cookie c1 = new Cookie("username", username);
		Cookie c2 = new Cookie("city", city);

		res.addCookie(c1);
		res.addCookie(c2);
		
		res.sendRedirect("/IPLab/servlet/DisplayCookies");
	}
}