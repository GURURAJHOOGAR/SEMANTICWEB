import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class ChangeColor extends HttpServlet
{
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		PrintWriter pw = res.getWriter();
		res.setContentType("text/html");
		
		String color = req.getParameter("color");
		
		pw.println("<html>");
		pw.println("<body bgcolor=" + color + ">");
		pw.println("<center><h1>The selected color is: " + color + "</h1></center>");
		pw.println("</body></html>");
		
		pw.close();
	}
}