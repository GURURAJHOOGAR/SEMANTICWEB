import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class DisplayCookies extends HttpServlet
{
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		PrintWriter pw = res.getWriter();
		res.setContentType("text/html");
		
		pw.println("<h1>This Page Displays All The Cookies</h1>");
		Cookie[] cookies = req.getCookies();
		
		for(Cookie c : cookies)
		{
			pw.println("Cookie Name: " + c.getName() + "<br>");
			pw.println("Cookie Value: " + c.getValue() + "<br><br>");
		}
	
		pw.close();
	}
}