import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Greet extends HttpServlet
{
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		PrintWriter pw = res.getWriter();
		res.setContentType("text/html");		
		
		String username = "";
		
		if(req.getParameter("username") != null)
			username = req.getParameter("username");
		
		if(username.trim().length() == 0)
			pw.println("<h1>Who are you?</h1>");
		else
			pw.println("<h1>Welcome, " + username + "</h1>");
		
		pw.close();
	}
}