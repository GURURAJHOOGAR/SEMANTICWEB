import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class ServerInfo extends HttpServlet
{
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		PrintWriter pw = res.getWriter();
		res.setContentType("text/html");
		
		pw.println("<h1>Server Info</h1>");
		
		pw.println("Server Name: "		+ req.getServerName() + "<br>");
		pw.println("Server Protocol: "	+ req.getProtocol()	  + "<br>");
		pw.println("Request Method: "	+ req.getMethod() 	  + "<br>");
		pw.println("Remote Address: "	+ req.getRemoteAddr() + "<br>");
		pw.println("URI: "				+ req.getRequestURI() + "<br>");
		pw.println("URL: "				+ req.getRequestURL() + "<br>");
		
		pw.close();
	}
}