import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class PassParams extends HttpServlet
{
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		PrintWriter pw = res.getWriter();
		res.setContentType("text/html");
		
		pw.println("<h1>Personal Details</h1>");
		pw.print("<hr><pre>");
		
		Enumeration e = req.getParameterNames();
		while(e.hasMoreElements())
		{
			String pname = (String) e.nextElement();
			String pvalue = req.getParameter(pname);
			
			pw.println(pname + " : " + pvalue + "<br>");
		}
		
		pw.print("</pre>");
		pw.close();
	}
}