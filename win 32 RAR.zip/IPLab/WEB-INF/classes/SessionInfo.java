import java.io.*;
import java.util.Enumeration;
import javax.servlet.*;
import javax.servlet.http.*;

public class SessionInfo extends HttpServlet
{
	public void doGet (HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		PrintWriter pw = res.getWriter();
		res.setContentType("text/html");
		
		HttpSession session = req.getSession(true);
		
		int hitCount = 1;		
		if(session.getAttribute("HitCount") != null)
			hitCount = (int) session.getAttribute("HitCount") + 1;
		session.setAttribute("HitCount", hitCount);
		
		pw.println("<h1>Session Info</h1>");
		pw.println("You have hit this page <b>" + hitCount + "</b> times.");
		
		pw.println("<h3>Session Data:</h3>");
		
		pw.println("New Session: "			+ session.isNew() 				+ "<br>");
		pw.println("Session ID: "			+ session.getId() 				+ "<br>");
		pw.println("Creation Time: "		+ session.getCreationTime() 	+ "<br>");
		pw.println("Last Accessed Time: "	+ session.getLastAccessedTime() + "<br>");
		
		pw.close();
	}
}