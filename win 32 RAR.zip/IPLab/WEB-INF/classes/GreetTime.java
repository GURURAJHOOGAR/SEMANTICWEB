import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.Calendar;
import java.text.SimpleDateFormat;

public class GreetTime extends HttpServlet
{
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		PrintWriter pw = res.getWriter();
		res.setContentType("text/html");
		
		Calendar cal = Calendar.getInstance();
		int hour = cal.get(Calendar.HOUR_OF_DAY);
		
		pw.println("<h1>" + GreetByTime(hour) + "</h1>");
		
		pw.println("<h2>");
		SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ss a");
		pw.println("Current Time : " + sdf.format(cal.getTime()));
		pw.println("</h2>");
		
		pw.close();
	}
	
	public String GreetByTime(int hour)
	{
		if(hour >= 6 && hour < 12)
			return "Good Morning";
		else if(hour >= 12 && hour < 18)
			return "Good Afternoon";
		else if(hour >= 18 && hour < 22)
			return "Good Evening";
		else if(hour >= 22 && hour < 24)
			return "Good Night";
		else
			return "You are up Late";
	}
}